const http = require('http');

const server = http.createServer((req, res)=>{
const user={
firstName:"kunkky",
surname:"ademuyiwa"
}
    const report = {
        greeting: "Hello World",
        user: user
    }
res.writeHead(200,{"Content-Type":"application/json"})
res.write(
JSON.stringify(report)
)

});

server.listen(2023,()=>{
    console.log("Listening  2023");
})
