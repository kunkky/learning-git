const email= "jsjshsgjjk@gmail.com"

function ValidateEmail(mail) {
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
        console.log(true);
    }
    else{
    console.log(false);
    }
}

ValidateEmail(email);